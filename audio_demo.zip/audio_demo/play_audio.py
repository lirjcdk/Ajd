# play_audio.py
# Enkel terminalspelare för mp3 med python-vlc.
# Installera först:
#   pip install python-vlc
#
# Kör:
#   python play_audio.py JANATANGRATER.mp3
# eller:
#   python play_audio.py GOOD_BOY.mp3

import sys
import time
import vlc

def main():
    if len(sys.argv) < 2:
        print("Användning: python play_audio.py <fil.mp3>")
        sys.exit(1)

    path = sys.argv[1]
    player = vlc.MediaPlayer(path)
    player.play()

    print(f"Spelar: {path} (Ctrl+C för att avsluta)")
    try:
        while True:
            state = player.get_state()
            if state in (vlc.State.Ended, vlc.State.Error, vlc.State.Stopped):
                break
            time.sleep(0.2)
    except KeyboardInterrupt:
        pass
    finally:
        player.stop()

if __name__ == "__main__":
    main()
